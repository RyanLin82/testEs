package com.eunice.carousell.service;



public interface CategoryService {
	void createCategory(String categoryName);
	
	void getCategory(String userName, String category);
	
	void getSortedCategory(String userName, String category, String sortType, String sortOrder);
	
	void getTopCategory(String userName);
}
