package com.eunice.carousell.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eunice.carousell.App;
import com.eunice.carousell.Message;
import com.eunice.carousell.model.Category;
import com.eunice.carousell.model.Listing;
import com.eunice.carousell.model.User;
import com.eunice.carousell.repository.CategoryRepository;
import com.eunice.carousell.repository.ListingRepository;
import com.eunice.carousell.repository.UserRepository;

@Service
public class ListingServiceImpl implements ListingService {

	private static org.apache.log4j.Logger logger = Logger.getLogger(App.class);
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ListingRepository listingRepository;
	
	@Autowired
	CategoryRepository categoryRepository;
	
	Message message;
	
	/**
	 * Create a listing.
	 */
	@Override
	public void createListing(String userName, String title, String description, int price, String categoryName) {
		boolean isUserExist = userRepository.exists(userName);
		boolean isCategoryExist = categoryRepository.exists(categoryName);
		Listing listing;
		if(!isUserExist) {
			logger.info(message.UNKNOW_USER);
		} 
		else if (!isCategoryExist) {
			logger.info(message.CATEGORY_NOT_FOUND);
		}
		else {	
			listing = new Listing(title, description, price, new User(userName), new Category(categoryName));
			listingRepository.save(listing);
			
			logger.info(Long.toString(listing.getId())); 
			logger.info(listing);
		}
	}

	/**
	 * Delete a listing by listing ID.
	 */
	@Override
	public void deleteListing(String userName, String listingId) {
		boolean isOwner = listingRepository.findById(Long.valueOf(listingId)).getUser().getUserName().equals(userName)? true:false;
		
		if(isOwner) {
			listingRepository.delete(Long.parseLong(listingId));
			logger.info(message.SUCCESS);
		}
		else {
			logger.info(message.OWNER_MISHMATCH);
		}
	}

	/**
	 * Get a listing by listing ID.
	 */
	@Override
	public void getListing(String userName, String listingId) {
		boolean isUserExist = userRepository.exists(userName);
		if(!isUserExist) {
			logger.info("Error - unknow user");
		} 
		else {
		Listing listing = listingRepository.findById(Long.parseLong(listingId));
		logger.info(listing.toString());
		logger.info(userName + " got " + listingId);
		
		}
	}
}
