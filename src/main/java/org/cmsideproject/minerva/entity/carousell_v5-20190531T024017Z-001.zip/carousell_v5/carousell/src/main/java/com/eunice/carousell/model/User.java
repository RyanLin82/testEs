package com.eunice.carousell.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "users")
public class User{
	@Id
	private String userName;
	
	@Column
	@OneToMany(fetch = FetchType.EAGER,
            cascade = CascadeType.ALL)
	private List<Listing> groupOfListing = new ArrayList<>();

	
	public User() {
//		super();
	}

	public User(String userName) {
		this.userName = userName;
//		groupOfListing = new ArrayList<>();
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public List<Listing> getListingGroup() {
		return groupOfListing;
	}

	public void setListingGroup(List<Listing> listingGroup) {
		this.groupOfListing = listingGroup;
	}

	@Override
    public String toString() {
        return "User{" + "userName=" + userName  + "}\n";
    }
}
