package com.eunice.carousell;


import java.util.Scanner;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.eunice.carousell.service.CategoryServiceImpl;
import com.eunice.carousell.service.ListingServiceImpl;
import com.eunice.carousell.service.UserServiceImpl;

/**
 * 
 *
 */
@SpringBootApplication
public class App implements CommandLineRunner{

	private static org.apache.log4j.Logger logger = Logger.getLogger(App.class);
	
	@Autowired
	private UserServiceImpl userServiceImpl;
	
	@Autowired
	private ListingServiceImpl listingServiceImpl;
	
	@Autowired
	private CategoryServiceImpl categoryServiceImpl;
	
    public static void main( String[] args )
    {
    	SpringApplication.run(App.class, args);
                       
    }

	@Override
	public void run(String... args) throws Exception {
		System.out.println( "Welcome to Eunicell" );

		Scanner userInput = new Scanner(System.in);
		processCommmand(userInput);
		
	}
	
	/**
	 * Process user input as command.
	 * @param userInput
	 */
	private void processCommmand(Scanner userInput) {
		boolean continueApp = true;
		while (continueApp) {
						
			switch(userInput.next()) {
				case "REGISTER":
					userServiceImpl.registerUser(userInput.next());
					break;
				
				case "CREATE_LISTING":
					listingServiceImpl.createListing(userInput.next(), userInput.next(), userInput.next(), userInput.nextInt(), userInput.next());
					break;
					
				case "DELETE_LISTING":					
					listingServiceImpl.deleteListing(userInput.next(),userInput.next());
				
				case "GET_LISTING":	
					listingServiceImpl.getListing(userInput.next(), userInput.next());
					break;
					
				case "CREATE_CATEGORY":
					categoryServiceImpl.createCategory(userInput.next());
					break;
					
				case "GET_CATEGORY":
					categoryServiceImpl.getCategory(userInput.next(),userInput.next());
					break;
				case "GET_SORTED_CATEGORY":
					categoryServiceImpl.getSortedCategory(userInput.next(), userInput.next(), userInput.next(), userInput.next());
					break;
				
				case "x":
					continueApp = false;
					logger.info("User entered x to exit the program.");
					break;
					
				default:
					logger.info("Command not found, please try again.");
					break;
			}
			userInput = new Scanner(System.in);
			
		}
		userInput.close();
		
		logger.info("Program Stopped");
		
	}
   


    
    
}
