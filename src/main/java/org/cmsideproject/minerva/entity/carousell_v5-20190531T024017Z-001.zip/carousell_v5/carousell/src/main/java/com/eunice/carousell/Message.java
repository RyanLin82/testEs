package com.eunice.carousell;

public class Message {
	public static final String SUCCESS = "Success";
	public static final String UNKNOW_USER = "Error - unknow user";
	public static final String USER_ALREADY_EXIST = "Error - user already existing";
	public static final String OWNER_MISHMATCH = "Error - listing owner mismatch";
	public static final String CATEGORY_NOT_FOUND = "Error - Category not found";
	
}
