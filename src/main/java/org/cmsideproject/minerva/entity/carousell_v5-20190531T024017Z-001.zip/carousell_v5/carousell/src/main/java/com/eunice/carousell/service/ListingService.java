package com.eunice.carousell.service;

import com.eunice.carousell.model.Listing;

public interface ListingService {	
	void createListing(String userName, String title, String description, int price, String category);
	
	void deleteListing(String userName, String listingId);

	void getListing(String userName, String listingId);

}
