package com.eunice.carousell.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eunice.carousell.App;
import com.eunice.carousell.Message;
import com.eunice.carousell.model.User;
import com.eunice.carousell.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	private static org.apache.log4j.Logger logger = Logger.getLogger(App.class);

	@Autowired
	UserRepository userRepository;
	
	Message message;

	@Override
	public void registerUser(String userName) {		
		if(userRepository.exists(userName)) {
			logger.info(message.USER_ALREADY_EXIST);		
		}
		else {
			userRepository.save(new User(userName));
			logger.info(message.SUCCESS);				 
		}		
	}	
}
