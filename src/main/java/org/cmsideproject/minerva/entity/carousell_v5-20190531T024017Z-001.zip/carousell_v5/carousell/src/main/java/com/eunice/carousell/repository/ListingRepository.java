package com.eunice.carousell.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.eunice.carousell.model.Listing;

@Repository
public interface ListingRepository extends JpaRepository<Listing, Long> {
	
	Listing findById(Long id);
	
	Listing findByTitle(String title);
	
	Listing findByUserUserName(String userName);
	
	List<Listing> findByCategoryCategoryName(String categoryName);

	List<Listing> findTop10ByOrderByPriceAsc();
	
	List<Listing> findTop10ByOrderByPriceDesc();
	
	
}
