package com.eunice.carousell.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "categories")
public class Category {
	@Id
	private String categoryName;
	
	@Column
	@OneToMany(fetch = FetchType.EAGER,
            cascade = CascadeType.ALL)
	private List<Listing> groupOfListing = new ArrayList<>();	;

	public Category() {
		
	}
	
	public Category(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public List<Listing> getGroupOfListing() {
		return groupOfListing;
	}

	public void setGroupOfListing(List<Listing> groupOfListing) {
		this.groupOfListing = groupOfListing;
	}
	
	/**
	 * Add a listing into the category.
	 * @param listing
	 */
	public void addListing(Listing listing) {
		groupOfListing.add(listing);
	}
	
	@Override
    public String toString() {
		return categoryName;
	}		
	
}
