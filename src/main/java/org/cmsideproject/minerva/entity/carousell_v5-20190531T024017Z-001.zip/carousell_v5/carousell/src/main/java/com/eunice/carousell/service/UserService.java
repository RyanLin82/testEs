package com.eunice.carousell.service;

import java.util.Scanner;

import com.eunice.carousell.model.User;

public interface UserService {
	void registerUser(String userName);
//	void registerUser(User user);
	
}
