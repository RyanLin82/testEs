package com.eunice.carousell.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eunice.carousell.App;
import com.eunice.carousell.model.Category;
import com.eunice.carousell.model.Listing;
import com.eunice.carousell.repository.CategoryRepository;
import com.eunice.carousell.repository.ListingRepository;
import com.eunice.carousell.repository.UserRepository;

@Service
public class CategoryServiceImpl implements CategoryService {
	
	private static org.apache.log4j.Logger logger = Logger.getLogger(App.class);
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ListingRepository listingRepository;
	
	@Autowired
	CategoryRepository categoryRepository;
	
	List<Listing> groupOfListing = null;
	
	/**
	 * Create a category.
	 */
	@Override
	public void createCategory(String categoryName) {
		Category category = new Category(categoryName);
		categoryRepository.save(category);
		logger.info("A new category, " + categoryName + ", is created");
	}
	
	/**
	 * Get all the listings in the given category name.
	 */
	@Override
	public void getCategory(String userName, String categoryName) {
		boolean isUserExist = userRepository.exists(userName);
		boolean isCategoryExist = categoryRepository.exists(categoryName);;
		
		if(!isUserExist) {
			logger.info("Error - unknow user");
			
		} 
		else if (!isCategoryExist) {
			logger.info("Category not found");
					
		} 
		else {
			groupOfListing = listingRepository.findByCategoryCategoryName(categoryName);			
			printOutListings(groupOfListing);
		}				
	}

	/**
	 * Get sorted listings in a given category name.
	 */
	@Override
	public void getSortedCategory(String userName, String categoryName, String sortType, String sortOrder) {
		boolean isUserExist = userRepository.exists(userName);
		boolean isCategoryExist = categoryRepository.exists(categoryName);;
		
		if(!isUserExist) {
			logger.info("Error - unknow user");
			
		} 
		else if (!isCategoryExist) {
			logger.info("Category not found");
	
		} 
		else {
			switch(sortType){
				case("sort_price"): 
					if(sortOrder.equals("asc")) {
						groupOfListing = listingRepository.findTop10ByOrderByPriceAsc();
						printOutListings(groupOfListing);
					}
					else if(sortOrder.equals("dsc")) {
						groupOfListing = listingRepository.findTop10ByOrderByPriceDesc();
						printOutListings(groupOfListing);
					}
					else
						logger.info("Error - Order not found");
					break;
				
				case("sort_time"):
					break;
			}					
		}		
	}

	@Override
	public void getTopCategory(String userName) {
		// TODO Auto-generated method stub
	}
	
	/**
	 * Print out a list of listings.
	 * @param groupOfListing
	 */
	public void printOutListings(List<Listing> groupOfListing) {
		for(Listing listing : groupOfListing) {
			logger.info(listing.toString());
		}
	}

}
