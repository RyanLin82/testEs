package com.eunice.carousell.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "listings")
public class Listing {
	@Id	
	@GeneratedValue
	private Long id;
	
	@Column
	private String title;
	
	@Column
	private String description;
	
	@Column
	private int price;
	
//	@Column
//	private String creationTime;
	
	@ManyToOne
	@JoinColumn(name="userName")
	private User user;
	
	@ManyToOne
	@JoinColumn(name="categoryName")
	private Category category;

	public Listing() {
	}

	public Listing(String title, String description, int price, User user) {
		this.title = title;
		this.description = description;
		this.price = price;
		this.user = user;
	}
		

	public Listing(String title, String description, int price, User user, Category category) {
//		super();
		this.title = title;
		this.description = description;
		this.price = price;
		this.user = user;
		this.category = category;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
		
	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	@Override
    public String toString() {
		return title + "|" + description + "|" + price + "|" + category.getCategoryName() + "|" + user.getUserName();
	}
}



